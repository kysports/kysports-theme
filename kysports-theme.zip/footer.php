<?php
/**
 * Theme footer placeholder.
 *
 * @package KySportsFoundation
 */
?>
<footer class="site-footer">
	<div class="site-footer__inner">
		<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
		<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => 'nav', 'container_class' => 'site-footer__navigation', 'fallback_cb' => false ) ); ?>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
