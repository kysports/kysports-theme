/**
 * Theme-wide JavaScript entry point.
 * Homepage interactions will be added in later sprints.
 */

( function () {
	'use strict';
}() );
