<?php
/**
 * Theme header placeholder.
 *
 * @package KySportsFoundation
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#main-content"><?php esc_html_e( 'Skip to content', 'kysports-foundation' ); ?></a>
<header class="site-header">
	<div class="site-header__inner">
		<?php the_custom_logo(); ?>
		<?php if ( ! has_custom_logo() ) : ?><a class="site-header__name" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a><?php endif; ?>
		<nav class="site-navigation" aria-label="<?php esc_attr_e( 'Primary navigation', 'kysports-foundation' ); ?>">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => false ) ); ?>
		</nav>
	</div>
</header>
